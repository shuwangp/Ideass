const User = require ('./User')
const idea = require ('./Idea')
const  Comment = require('./Comment')
const Vote = require('./vote')

module.exports = {
    User,
    idea,
    Comment,
    Vote
};